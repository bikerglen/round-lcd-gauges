extern const uint32_t dialCo2[57600];
extern const uint32_t dialClockish[57600];
extern const uint32_t dialPercent[57600];
extern const uint32_t needleRed[57600];
extern const uint32_t pointerClockish[57600];
extern const uint32_t pointerBlack[57600];
